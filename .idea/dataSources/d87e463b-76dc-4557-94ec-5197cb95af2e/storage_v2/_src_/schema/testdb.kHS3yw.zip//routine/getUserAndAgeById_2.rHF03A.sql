create
    definer = root@localhost procedure getUserAndAgeById_2(IN userId int, OUT userName varchar(50), OUT userAge int)
begin
	select `name` into userName from `user` where id = userId;
	select `age` into userAge from `user` where id = userId;
end;

